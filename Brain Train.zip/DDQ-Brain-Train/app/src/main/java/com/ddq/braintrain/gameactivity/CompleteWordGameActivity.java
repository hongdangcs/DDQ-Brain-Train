package com.ddq.braintrain.gameactivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ddq.braintrain.R;

public class CompleteWordGameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_word_game);
    }
}